"""Démarre le serveur ERP à l'intérieur de l'application (aucun PC, aucun réseau) : base SQLite privée dans le stockage de l'appli."""
import os, threading

_port = None

def demarrer(dossier_donnees, dossier_web):
    """Retourne le port local (127.0.0.1) sur lequel l'ERP répond. Sans effet si déjà démarré."""
    global _port
    if _port:
        return _port
    os.makedirs(dossier_donnees, exist_ok=True)
    os.environ['ATELIER_DB'] = os.path.join(dossier_donnees, 'atelier.db')   # avant l'import de server
    import server
    server.BASE = dossier_web          # contient static/index.html (copié depuis les assets)
    server.init_db(False)
    threading.Thread(target=server.boucle_sauvegarde, daemon=True, name='sauvegardes-automatiques').start()
    srv = server.ThreadingHTTPServer(('127.0.0.1', 0), server.H)   # port libre choisi par le système
    threading.Thread(target=srv.serve_forever, daemon=True, name='erp-http').start()
    _port = srv.server_address[1]
    return _port
