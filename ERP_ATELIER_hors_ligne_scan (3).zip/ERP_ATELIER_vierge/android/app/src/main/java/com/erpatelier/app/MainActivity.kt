package com.erpatelier.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private val reqFile = 41
    private val reqScan = 42
    private var scanUri: Uri? = null
    private var base = ""          // adresse locale de l'ERP embarqué, ex. http://127.0.0.1:41873

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF1E2A38.toInt()
        File(cacheDir, "share").listFiles()?.forEach { it.delete() }

        web = WebView(this)
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            textZoom = 100
        }
        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(Bridge(), "AndroidApp")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val b = Uri.parse(base)
                if (u.host == b.host && u.port == b.port) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError()
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {}
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }.show()
                return true
            }
            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Annuler") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                chooserCb?.onReceiveValue(null); cameraUri = null
                chooserCb = cb
                val acc = params.acceptTypes.filter { it.contains("/") }
                val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (acc.size == 1) acc[0] else "*/*"
                    if (acc.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, acc.toTypedArray())
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                val extra = mutableListOf<Intent>()
                if (params.acceptTypes.all { it.isBlank() } || acc.any { it.startsWith("image") }) {
                    try {
                        val dir = File(cacheDir, "share").apply { mkdirs() }
                        val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                        cameraUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                        extra += Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            .putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) { cameraUri = null }
                }
                val chooser = Intent.createChooser(pick, "Choisir un fichier")
                    .putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toTypedArray())
                return try {
                    startActivityForResult(chooser, reqFile); true
                } catch (_: Exception) {
                    chooserCb = null; cb.onReceiveValue(null); false
                }
            }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            download(url, CookieManager.getInstance().getCookie(url), ua, URLUtil.guessFileName(url, cd, mime), mime)
        }

        load()
    }

    // ---------- Démarrage de l'ERP embarqué (Python dans l'application) ----------
    private fun load() {
        web.loadDataWithBaseURL(null, "<html><body style=\"font-family:sans-serif;background:#f4f2ee;color:#23211e;padding:32px\"><h3>Démarrage de l'ERP…</h3></body></html>", "text/html", "utf-8", null)
        thread {
            try {
                copyAssets("erp_static", File(filesDir, "web/static"))
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val port = Python.getInstance().getModule("android_main")
                    .callAttr("demarrer", File(filesDir, "data").absolutePath, File(filesDir, "web").absolutePath).toInt()
                base = "http://127.0.0.1:$port"
                runOnUiThread { web.loadUrl(base) }
            } catch (e: Exception) {
                runOnUiThread { showError(e.message ?: e.toString()) }
            }
        }
    }

    private fun copyAssets(src: String, dst: File) {
        val names = assets.list(src) ?: return
        if (names.isEmpty()) {
            dst.parentFile?.mkdirs()
            assets.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            names.forEach { copyAssets("$src/$it", File(dst, it)) }
        }
    }

    private fun showError(msg: String = "") {
        val html = """
            <html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="font-family:sans-serif;padding:24px;background:#f4f2ee;color:#23211e">
            <h2>L'ERP n'a pas pu démarrer</h2>
            <p style="color:#7a756c">${msg.replace("<", "&lt;")}</p>
            <button style="font-size:18px;padding:12px 20px;background:#0f766e;color:#fff;border:0;border-radius:6px" onclick="AndroidApp.retry()">Réessayer</button>
            </body></html>
        """.trimIndent()
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    // ---------- Pont JavaScript ----------
    inner class Bridge {
        @JavascriptInterface fun print() { runOnUiThread { doPrint() } }
        @JavascriptInterface fun openPdf(url: String) { download(url, CookieManager.getInstance().getCookie(url), web.settings.userAgentString, URLUtil.guessFileName(url, null, "application/pdf"), "application/pdf") }
        @JavascriptInterface fun scan() { runOnUiThread { startScan() } }
        @JavascriptInterface fun retry() { runOnUiThread { load() } }
    }

    private fun doPrint() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val name = "ERP_" + System.currentTimeMillis()
        pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
    }

    // ---------- Téléchargements / PDF ----------
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

    private fun download(url: String, cookie: String?, ua: String?, rawName: String, mime: String?) {
        toast("Téléchargement…")
        thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 60000
                if (cookie != null) c.setRequestProperty("Cookie", cookie)
                if (ua != null) c.setRequestProperty("User-Agent", ua)
                if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
                val type = (c.contentType ?: mime ?: "application/octet-stream").substringBefore(';').trim()
                var name = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (type == "application/pdf") {
                    if (!name.endsWith(".pdf", true)) name = name.substringBeforeLast('.') + ".pdf"
                    val f = File(File(cacheDir, "share").apply { mkdirs() }, name)
                    c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                    runOnUiThread {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        } catch (_: Exception) { toast("Aucune application PDF installée sur ce téléphone") }
                    }
                } else if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, type)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                    contentResolver.openOutputStream(uri)!!.use { o -> c.inputStream.use { it.copyTo(o) } }
                    toast("Enregistré dans Téléchargements : $name")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                    val f = File(dir, name)
                    c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    toast("Enregistré : ${f.absolutePath}")
                }
            } catch (e: Exception) {
                toast("Échec du téléchargement : ${e.message}")
            }
        }
    }


    // ---------- Scanner : photo -> texte (ML Kit, hors connexion) -> interface de l'ERP ----------
    private fun startScan() {
        try {
            val f = File(File(cacheDir, "share").apply { mkdirs() }, "scan_${System.currentTimeMillis()}.jpg")
            scanUri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val cam = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, scanUri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pick = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            val chooser = Intent.createChooser(pick, "Photo du document").putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cam))
            startActivityForResult(chooser, reqScan)
        } catch (e: Exception) {
            toast("Impossible d'ouvrir l'appareil photo : ${e.message}")
        }
    }

    private fun sendToWeb(json: JSONObject) {
        runOnUiThread { web.evaluateJavascript("window.onScan(" + json.toString() + ")", null) }
    }

    private fun scanError(msg: String) = sendToWeb(JSONObject().put("erreur", msg))

    private fun loadBitmap(uri: Uri): Bitmap {
        val o1 = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o1) }
        var step = 1
        while (maxOf(o1.outWidth, o1.outHeight) / step > 3000) step *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = step }
        var bmp = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw Exception("image illisible")
        val deg = contentResolver.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }
        if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        return bmp
    }

    private fun onScanResult(resultCode: Int, data: Intent?) {
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: scanUri ?: return
        toast("Lecture du texte…")
        thread {
            try {
                val bmp = loadBitmap(uri)
                val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                rec.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener { t ->
                        try {
                            val arr = JSONArray()
                            for (blk in t.textBlocks) for (l in blk.lines) {
                                val r = l.boundingBox ?: continue
                                arr.put(JSONObject().put("t", l.text).put("left", r.left).put("top", r.top).put("right", r.right).put("bottom", r.bottom))
                            }
                            val k = 900f / maxOf(bmp.width, bmp.height)
                            val small = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
                            val bo = ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG, 70, bo)
                            sendToWeb(JSONObject().put("image", "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)).put("lignes", arr))
                        } catch (e: Exception) { scanError("Lecture impossible : ${e.message}") }
                        rec.close()
                    }
                    .addOnFailureListener { e -> scanError("Lecture impossible : ${e.message}"); rec.close() }
            } catch (e: Exception) {
                scanError("Photo illisible : ${e.message}")
            }
        }
    }

    // ---------- Sélecteur de fichiers / appareil photo ----------
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqScan) { onScanResult(resultCode, data); return }
        if (requestCode == reqFile) {
            val cb = chooserCb; chooserCb = null
            var out: Array<Uri>? = null
            if (resultCode == RESULT_OK) {
                val clip = data?.clipData
                val single = data?.data
                out = when {
                    clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                    single != null -> arrayOf(single)
                    cameraUri != null -> arrayOf(cameraUri!!)   // photo prise avec l'appareil
                    else -> null
                }
            }
            cb?.onReceiveValue(out)
            return
        }
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        @Suppress("DEPRECATION")
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }
}
